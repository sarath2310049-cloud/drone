# ESP32-CAM Warehouse QR Scanner

A warehouse inventory QR-scanning demonstration. The ESP32-CAM decodes a QR payload and sends the decoded text over Wi-Fi to a Flask server running on a laptop. Flask records each received scan event in `results.csv`.

## Architecture

1. A QR label contains inventory text.
2. ESP32-CAM decodes the QR payload.
3. ESP32-CAM sends JSON to `POST /qrdata`.
4. Flask parses inventory fields and appends a row to `results.csv`.

**This project sends decoded text, not captured image files.** Report ESP32-CAM performance only after actually testing with the hardware.

## QR label format

Use one field per line:

```text
Item ID: WH001
Product: DC Motor Assembly
Quantity: 120
Location: Rack A-01
```

Other QR text is still saved in `raw_payload`, though parsed columns may be blank.

## Files

- `app.py` — Flask endpoint and CSV logging.
- `requirements.txt` — Python dependency.
- `esp32_cam_qr_scanner.ino` — Arduino sketch.
- `results.csv` — created automatically after the first successful scan; do not fabricate results.

## Laptop setup (Windows)

1. Install Python 3.
2. Open Command Prompt in this folder.
3. Install dependencies:

   ```cmd
   py -m pip install -r requirements.txt
   ```

4. Start Flask:

   ```cmd
   py app.py
   ```

5. Find your laptop IPv4 address:

   ```cmd
   ipconfig
   ```

Use the IPv4 address of the Wi-Fi adapter connected to the ESP32-CAM network.

## ESP32-CAM setup

1. Install ESP32 board support in Arduino IDE.
2. Install `ArduinoJson` and a compatible `ESP32QRCodeReader` library.
3. Open `esp32_cam_qr_scanner.ino`.
4. Replace `WIFI_NAME`, `WIFI_PASSWORD`, and `LAPTOP_IP`.
5. Select the correct ESP32-CAM board/port and upload.
6. Open Serial Monitor at `115200` baud.
7. Show a QR label to the camera.

The `ESP32QRCodeReader` API differs between library forks. If `DecodedQR`, `setCallback`, or `beginOnCore` is undefined, adapt the sketch to the example/API supplied with your installed library.

## Verify

- Flask reports `POST /qrdata` and a successful response.
- Serial Monitor shows the HTTP status and server response.
- `results.csv` appears beside `app.py` and records timestamp, parsed fields, raw payload, and status.

## Troubleshooting

- Laptop and ESP32-CAM must be on the same Wi-Fi network.
- Use the laptop IPv4 address, not `127.0.0.1`, in the ESP32 sketch.
- Allow Python through Windows Firewall on private networks if prompted.
- Some guest Wi-Fi/hotspot networks block device-to-device communication.
- Do not expose Flask's development server directly to the public internet.

## Experimental reporting

Record only measured values. Log the number of unique labels attempted, scan events received, successful decodes, camera-to-label distance, label dimensions, and lighting conditions. This code logs received scan events; it does not identify unique labels or prevent repeated scans of the same QR.

## Security

Do not commit real Wi-Fi credentials to a public repository. Keep placeholders in GitHub and enter credentials locally.
